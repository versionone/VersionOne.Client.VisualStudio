namespace VersionOne.VisualStudio.DataLayer {
    public class TestProject : Project {
        public TestProject() : base(null, null) { }
    }
}
