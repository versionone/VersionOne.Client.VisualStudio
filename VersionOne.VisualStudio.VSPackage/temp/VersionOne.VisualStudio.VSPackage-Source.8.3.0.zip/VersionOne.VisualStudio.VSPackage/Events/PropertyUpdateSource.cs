namespace VersionOne.VisualStudio.VSPackage.Events {
    public enum PropertyUpdateSource {
        ProjectView,
        ProjectPropertyView,
        WorkitemView,
        WorkitemPropertyView,
    }
}