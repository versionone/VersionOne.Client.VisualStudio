﻿// PkgCmdID.cs
// MUST match PkgCmdID.h
namespace VersionOne.VisualStudio.VSPackage {
    static class PkgCmdIDList {
        public const uint CmdidVersionOneTasks = 0x101;
        public const uint CmdidVersionOneProjects = 0x102;
    };
}