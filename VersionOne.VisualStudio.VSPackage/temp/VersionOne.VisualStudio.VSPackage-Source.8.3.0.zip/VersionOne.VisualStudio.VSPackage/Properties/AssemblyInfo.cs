﻿using System;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("VersionOne Tracker")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("VersionOne")]
[assembly: AssemblyProduct("VersionOne Tracker")]
[assembly: AssemblyCopyright("Copyright © VersionOne 2010")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]   
[assembly: ComVisible(false)]     
[assembly: CLSCompliant(false)]
[assembly: NeutralResourcesLanguage("en-US")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Revision and Build Numbers 
// by using the '*' as shown below:

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

// TODO
[assembly: InternalsVisibleTo("VersionOne.VisualStudio.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100f33b1033203ca9ff9ce73372ac29a743c997d40a51056e6a7525e08636a07746991f957dc95e4d74523b6b3573e169e0136d53ee4ef8c0ff218583e330633afcdd3ee03dc0b1dbab12ce2d6f4045250e59ea2074e8ab52897b2b27ea4f9e62bf7cde46c16f24f15f014fd4386998b64ef88ac427d00cb777723bdc196d9763a2")]