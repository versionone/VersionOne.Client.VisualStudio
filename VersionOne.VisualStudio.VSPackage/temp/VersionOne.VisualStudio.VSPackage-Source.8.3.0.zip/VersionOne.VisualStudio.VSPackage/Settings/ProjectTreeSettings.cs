namespace VersionOne.VisualStudio.VSPackage.Settings {
    public class ProjectTreeSettings {
        private ColumnSetting[] columns;

        public ColumnSetting[] Columns {
            get { return columns; }
            set { columns = value; }
        }
    }
}
